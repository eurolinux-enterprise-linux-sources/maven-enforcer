package org.apache.maven.plugins.enforcer.util;


/**
 * @author <a href="mailto:brianf@apache.org">Brian Fox</a>
 *
 */
public class EnforcerUtils
{

}
